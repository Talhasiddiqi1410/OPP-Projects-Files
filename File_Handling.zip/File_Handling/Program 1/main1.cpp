#include <iostream>
#include <fstream>  
using namespace std;
int main() {
    // Create an ofstream object for file output
    ofstream outFile("example.txt");

    // Write some text to the file
    outFile << "Hello, this is a test file by IMRAN MANZOOR." << endl;
    outFile << "Writing some more text to the file." << endl;

    // Close the file stream
    outFile.close();

    // Notify the user
    cout << "File created and text written successfully." << endl;

    return 0; 
}
