#include <iostream>
#include <fstream>
using namespace std;

int main() {
    // File stream objects
    ifstream sourceFile("source.txt");
    ofstream destinationFile("destination.txt");

    // Check if files are open
    if (!sourceFile.is_open() || !destinationFile.is_open()) {
        cerr << "Error opening files!" << endl;
        return 1;
    }

    // Copy contents line by line
    string line;
    while (getline(sourceFile, line)) {
        destinationFile << line << endl;
    }

    // Close the files
    sourceFile.close();
    destinationFile.close();

    cout << "File copied successfully!" << endl;
    return 0;
}
