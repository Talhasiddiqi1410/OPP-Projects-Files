#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

int main() {
    string filename = "example.txt";
    ifstream inputFile(filename);
    if (!inputFile) {
        cerr << "Error: Unable to open file " << filename << endl;
        return 1; 
    }
    
    string line;
    int wordCount = 0;

    while (getline(inputFile, line)) {
        istringstream lineStream(line);
        string word;
        while (lineStream >> word) {
            ++wordCount;
        }
    }

    
    inputFile.close();

    cout << "Number of words in the file: " << wordCount << endl;

    return 0; 
}
