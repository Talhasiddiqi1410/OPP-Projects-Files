#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
    // Define the name of the file to open
    string filename = "example.txt";

    // Create an input file stream object
    ifstream inputFile(filename);

    // Check if the file was successfully opened
    if (!inputFile) {
      cerr << "Error: Unable to open file " << filename << endl;
        return 1; // Exit with an error code
    }

    // Variable to hold each line of the file
    string line;

    // Variable to count the number of lines
    int lineCount = 0;

    // Read the file line by line
    while (getline(inputFile, line)) {
        // Increment the line count for each line read
        ++lineCount;
    }

    // Close the file
    inputFile.close();

    // Output the number of lines
    cout << "Number of lines in the file: " << lineCount << endl;

    return 0; // Exit successfully
}
